Steps to contribute are:
- Fork the original repository https://github.com/johri002/Automatic-leaf-infection-identifier 
- Clone or download the repository in your pc.
- Read the codes and run main.py according to the readme.md file to understand better.
- Work on the issues mentioned https://github.com/johri002/Automatic-leaf-infection-identifier/issues or find out your own issue and add them there.
- Commit the changes regarding the issues and generate the pull requests from the parent repository specifying the issues fixed.
