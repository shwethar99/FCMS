import pandas as pd
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import accuracy_score 
from sklearn.metrics import classification_report 
import sys	
# import warnings filter
from warnings import simplefilter
# ignore all future warnings
simplefilter(action='ignore', category=FutureWarning)
df = pd.read_csv("Datasetinfectedhealthy.csv")
ff = pd.read_csv("datasetlog/Datasetunlabelledlog.csv")
ff['label'] = ''


df.reset_index(inplace = True)
df.drop(columns = ['fortnum','imgid'],inplace = True)
ff.reset_index(inplace = True)
ff.drop(columns = ['fortnum','imgid'],inplace = True)

#print("Training dataset by splitting Datasetinfectedhealthy.csv")
#train_x,test_x ,train_y, test_y = model_selection.train_test_split(df[['feature1','feature2','feature3']],df['label'])



#print(pred)
#results = confusion_matrix(test_y, pred)
#print ('Accuracy Score :',accuracy_score(test_y, pred))
#print ('Report : ')
#print (classification_report(test_y,pred))
#print(results)

print("predicting for Unlabelled dataset")
train_x = df[['feature1','feature2','feature3']]
train_y = df['label']
test_x = ff[['feature1','feature2','feature3']]
test_y = ff['label']

clf = RandomForestClassifier()
clf.fit(train_x,train_y)
pred = clf.predict(test_x)

print("Prediction:",pred[-1])
if(pred[-1]==0):
	print("The leaf is sufficiently healthy!")
else:
	print("The leaf is infected!")


ff['label'] = pd.Series(pred)

ff.to_csv("Datasetlabelledlog.csv",index = False)
sys.exit(0)
